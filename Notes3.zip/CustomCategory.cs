﻿using System;

namespace Notes
{

    [Serializable]
    internal class CustomCategory : BaseCategory
    {
        
        public CustomCategory(string name) : base(name){}
    }
}