﻿
namespace Notes
{
    public interface INote
    {
        string Heading
        {
            get;
            set;
        }

        string Body
        {
            get;
            set;
        }
    }
}
