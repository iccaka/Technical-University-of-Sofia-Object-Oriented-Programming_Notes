# Notes

*A Windows Forms application created for a university project. It's basically your standard notes app in which the user can save whatever notes he or she wants and categorize them into categories of choice.*

## Built With

* [Visual Studio](https://visualstudio.microsoft.com) - *The IDE used*

## Authors

* **Hristo Mitsev** - *Initial work* - [iccaka](https://github.com/iccaka)

See also the list of [contributors](https://github.com/iccaka/Technical-University-of-Sofia-Notes-Project/graphs/contributors) who participated in this project.

## License

This project is licensed under the MIT License - *see the* [LICENSE.md](https://github.com/iccaka/Technical-University-of-Sofia-Notes-Project/blob/master/LICENSE.md) *file for details.*
